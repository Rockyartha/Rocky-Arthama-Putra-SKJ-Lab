#include <iostream>

using namespace std;

int main(){
    int num1 = 5;
    int num2 = 10;
    int result = num1 * num2;

    cout << result;
}